SOURCES += __init__.py \
           plugin_upload.py \
           pdm_importar_md.py \
           pdm_importar_md_dialog.py

TRANSLATIONS += i18n/pdm_importar_md_pt_PT.ts
